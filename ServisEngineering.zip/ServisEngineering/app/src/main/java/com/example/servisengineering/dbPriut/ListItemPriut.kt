package com.example.servisengineering.dbPriut

class ListItemPriut {

    var title: String = "empty"
    var desc: String = "empty"
    var uri: String = "empty"
    var id = 0
    var date = ""
    var status = "empty"

}