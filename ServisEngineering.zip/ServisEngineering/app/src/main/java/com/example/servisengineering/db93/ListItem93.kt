package com.example.servisengineering.db93

class ListItem93 {

    var title: String = "empty"
    var desc: String = "empty"
    var uri: String = "empty"
    var id = 0
    var date = ""
    var status = "empty"

}